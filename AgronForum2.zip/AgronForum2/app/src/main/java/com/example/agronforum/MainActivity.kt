package com.example.agronforum

import android.app.Activity

class MainActivity : Activity() {

}
