package com.example.agronforum;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class PersonalizeVaaniActivity extends AppCompatActivity {

    private EditText inputIndex;
    private EditText inputStock;
    private EditText inputCommodity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personalize_vaani);

        // Bind views
        inputIndex = findViewById(R.id.inputIndex);
        inputStock = findViewById(R.id.inputStock);
        inputCommodity = findViewById(R.id.inputCommodity);
        Button btnNext = findViewById(R.id.btnNext);
        
        // Optional: Close button functionality
        View btnClose = findViewById(R.id.btnClose);
        if (btnClose != null) {
            btnClose.setOnClickListener(v -> finish());
        }

        btnNext.setOnClickListener(v -> {
            String index = inputIndex.getText().toString().trim();
            String stock = inputStock.getText().toString().trim();
            String commodity = inputCommodity.getText().toString().trim();

            // Validate fields
            boolean isValid = true;

            if (index.isEmpty()) {
                inputIndex.setError("Required field");
                isValid = false;
            }

            if (stock.isEmpty()) {
                inputStock.setError("Required field");
                isValid = false;
            }

            if (commodity.isEmpty()) {
                inputCommodity.setError("Required field");
                isValid = false;
            }

            if (isValid) {
                // All fields filled -> Go to Step 2
                Intent intent = new Intent(PersonalizeVaaniActivity.this, PersonalizeVaaniStep2Activity.class);
                startActivity(intent);
            } else {
                Toast.makeText(PersonalizeVaaniActivity.this, "Please fill all required fields", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
