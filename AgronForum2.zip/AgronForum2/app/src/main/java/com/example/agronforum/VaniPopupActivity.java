package com.example.agronforum;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;

public class VaniPopupActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageView close = findViewById(R.id.btnClose);
        Button unlock = findViewById(R.id.btnUnlock);

        if (close != null) {
            close.setOnClickListener(v -> finish());
        }

        if (unlock != null) {
            unlock.setOnClickListener(v -> {
                Intent intent = new Intent(VaniPopupActivity.this, PersonalizeVaaniActivity.class);
                startActivity(intent);
            });
        }
    }
}
