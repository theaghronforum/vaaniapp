// This file is commented out to avoid duplicate class definition with VaniPopupActivity.java
// and conflict with MainActivity.kt
/*
package com.example.agronforum;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;

public class VaniPopupActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageView close = findViewById(R.id.btnClose);
        Button unlock = findViewById(R.id.btnUnlock);

        close.setOnClickListener(v -> finish());

        unlock.setOnClickListener(v -> {
            // Next screen / questions page
        });
    }
}
*/
