package com.example.agronforum;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class PersonalizeVaaniStep2Activity extends AppCompatActivity {

    private EditText inputSector;
    private EditText inputCrypto;
    private Button btnStartup, btnPolitics, btnBoth;
    private String selectedInterest = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personalize_vaani_step2);

        // Bind views
        inputSector = findViewById(R.id.inputSector);
        inputCrypto = findViewById(R.id.inputCrypto);
        
        btnStartup = findViewById(R.id.btnStartup);
        btnPolitics = findViewById(R.id.btnPolitics);
        btnBoth = findViewById(R.id.btnBoth);
        
        Button btnBack = findViewById(R.id.btnBack);
        Button btnGetVani = findViewById(R.id.btnGetVani);
        View btnClose = findViewById(R.id.btnClose);

        // Close button logic
        if (btnClose != null) {
            btnClose.setOnClickListener(v -> finish());
        }

        // Choice Button Logic
        if (btnStartup != null) btnStartup.setOnClickListener(v -> selectInterest("Startup News"));
        if (btnPolitics != null) btnPolitics.setOnClickListener(v -> selectInterest("Politics"));
        if (btnBoth != null) btnBoth.setOnClickListener(v -> selectInterest("Both"));

        // Back button logic
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }

        // "Get Vani" button logic - Navigates to VaaniActivity
        if (btnGetVani != null) {
            btnGetVani.setOnClickListener(v -> {
                String sector = inputSector.getText().toString().trim();
                String crypto = inputCrypto.getText().toString().trim();

                boolean isValid = true;

                if (sector.isEmpty()) {
                    inputSector.setError("Required field");
                    isValid = false;
                }

                if (crypto.isEmpty()) {
                    inputCrypto.setError("Required field");
                    isValid = false;
                }

                if (selectedInterest.isEmpty()) {
                    Toast.makeText(this, "Please select an interest (Startup News, Politics, or Both)", Toast.LENGTH_SHORT).show();
                    isValid = false;
                }

                if (isValid) {
                    // Navigate to VaaniActivity (The final screen)
                    Intent intent = new Intent(PersonalizeVaaniStep2Activity.this, VaaniActivity.class);
                    // Clear the back stack so this becomes the new root of the task
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                }
            });
        }
    }

    private void selectInterest(String interest) {
        selectedInterest = interest;
        
        // Reset all buttons to default style
        resetButtonStyle(btnStartup);
        resetButtonStyle(btnPolitics);
        resetButtonStyle(btnBoth);

        // Highlight the selected button
        Button selectedButton = null;
        if (interest.equals("Startup News")) selectedButton = btnStartup;
        else if (interest.equals("Politics")) selectedButton = btnPolitics;
        else if (interest.equals("Both")) selectedButton = btnBoth;

        if (selectedButton != null) {
             selectedButton.setBackgroundResource(R.drawable.button_filled);
             selectedButton.setTextColor(ContextCompat.getColor(this, android.R.color.white));
        }
    }

    private void resetButtonStyle(Button btn) {
        if (btn != null) {
            btn.setBackgroundResource(R.drawable.bg_choice_button); // This is your unselected outline
            btn.setTextColor(ContextCompat.getColor(this, android.R.color.black));
        }
    }
}
